"""
Builtin validation handlers registry.
"""

from typing import Callable
from validedi.handlers.npi import luhn_check
from validedi.handlers.cross_segment import (
    charge_total_consistency,
    charge_total_consistency_i,
    date_range_check,
    dob_vs_claim_date,
)
from validedi.handlers.duplicate_check import duplicate_member_check
from validedi.handlers.diagnosis_codes import validate_diagnosis_code

# Registry mapping handler names to callables
BUILTIN_HANDLERS: dict[str, Callable] = {
    'luhn_check': luhn_check,
    'charge_total_consistency': charge_total_consistency,
    'charge_total_consistency_i': charge_total_consistency_i,
    'date_range_check': date_range_check,
    'dob_vs_claim_date': dob_vs_claim_date,
    'duplicate_member_check': duplicate_member_check,
    'validate_diagnosis_code': validate_diagnosis_code,
}

__all__ = ['BUILTIN_HANDLERS']
