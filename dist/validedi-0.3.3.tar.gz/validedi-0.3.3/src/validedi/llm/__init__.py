"""
ValidEDI LLM Integration
========================

LLM-powered explanations, Q&A, and configuration management for EDI validation.

Usage:
    from validedi import parse, validate
    from validedi.llm import explain, ask_followup, add_custom_config
    
    # Define your LLM function (any provider)
    def my_llm(prompt: str) -> str:
        # Your LLM implementation
        return response
    
    # Parse and validate
    edi_result = parse("file.edi")
    val_result = validate(edi_result)
    
    # Get explanation
    explanation = explain(edi_result, val_result, llm=my_llm)
    print(explanation.report)
    
    # Ask follow-up questions
    answer = ask_followup("What is the total billed?", edi_result, val_result, llm=my_llm)
    print(answer)
    
    # Add custom configuration
    result = add_custom_config(
        context="Add a rule to check that claim amounts don't exceed $50,000",
        llm=my_llm,
        config_type="rule"
    )
    print(result)
"""

from .explainer import LLMExplainer, ExplainResult, explain, ask_followup
from .config_updater import LLMConfigUpdater, ConfigUpdateResult, add_custom_config

__all__ = [
    'LLMExplainer', 
    'ExplainResult', 
    'explain', 
    'ask_followup',
    'LLMConfigUpdater',
    'ConfigUpdateResult',
    'add_custom_config'
]
